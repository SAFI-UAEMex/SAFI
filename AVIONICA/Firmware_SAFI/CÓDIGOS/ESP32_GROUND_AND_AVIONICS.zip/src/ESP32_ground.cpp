#include <Arduino.h>

// ==========================================
// PINES DEL MÓDULO E22-900T22D
// ==========================================
// Serial2 del ESP32
const int RX2_PIN = 16;
const int TX2_PIN = 17;

// Pines de Control de Modo
const int PIN_LORA_M0 = 15;
const int PIN_LORA_M1 = 4;

void setup() {
  // 1. Configurar pines de control como salidas
  pinMode(PIN_LORA_M0, OUTPUT);
  pinMode(PIN_LORA_M1, OUTPUT);
  
  // 2. Forzar MODO 0 (Modo Normal / Transmisión Transparente)
  digitalWrite(PIN_LORA_M0, LOW);
  digitalWrite(PIN_LORA_M1, LOW);

  // 3. Iniciar puerto serial de la computadora (Monitor Serial) a alta velocidad
  Serial.begin(115200); 
  Serial.setTimeout(10); // CRÍTICO: Lee tu teclado instantáneamente sin pausar la recepción
  
  // 4. Iniciar puerto serial para comunicarse con el LoRa
  // IMPORTANTE: Está a 115200 baudios para soportar la ráfaga de 10 Hz.
  Serial2.begin(115200, SERIAL_8N1, RX2_PIN, TX2_PIN);

  delay(500);
  
  Serial.println("\n==========================================================");
  Serial.println(" [SISTEMA INICIADO] ESTACIÓN TERRENA AKBAL II             ");
  Serial.println(" Microcontrolador: ESP32 WROOM 32                         ");
  Serial.println(" RF: LoRa E22-900T22D (Modo Transparente)                 ");
  Serial.println("==========================================================");
  Serial.println(" >>> SISTEMA UPLINK ARMADO Y LISTO <<<                    ");
  Serial.println(" Comandos de inyección manual habilitados.                ");
  Serial.println(" Ráfaga de seguridad (10x) activa para emergencias.       ");
  Serial.println("==========================================================\n");
  
  // Imprimir el encabezado actualizado para coincidir con la cadena LoRa de la Teensy
  Serial.println("AltRelativa,TempBaro,Presion,VelVert,Lat,Lng,Ax,Ay,Az,Fase");
  Serial.println("----------------------------------------------------------");
}

void loop() {
  // =================================================================
  // TAREA 1: ESCUCHAR TELEMETRÍA DEL COHETE (DOWNLINK)
  // =================================================================
  if (Serial2.available()) {
    String paqueteTelemetria = Serial2.readStringUntil('\n');
    paqueteTelemetria.trim();
    
    if (paqueteTelemetria.length() > 0) {
      Serial.println(paqueteTelemetria);
    }
  }

  // =================================================================
  // TAREA 2: ENVIAR COMANDOS MANUALES AL COHETE (UPLINK)
  // =================================================================
  if (Serial.available()) {
    String comandoUplink = Serial.readStringUntil('\n');
    comandoUplink.trim(); // Limpia espacios o saltos de línea basura
    
    if (comandoUplink.length() > 0) {
      
      // VERIFICACIÓN DE EMERGENCIA (BOTÓN DE PÁNICO CON NUEVA PALABRA)
      if (comandoUplink == "Oh Fuck" || comandoUplink == "Calajo") {
        Serial.println("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        Serial.print(">>> INICIANDO RÁFAGA DE EMERGENCIA (10x): ");
        Serial.println(comandoUplink);
        Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        
        // Bucle de ráfaga redundante
        for (int i = 0; i < 10; i++) {
          Serial2.println(comandoUplink); // Dispara al aire
          
          Serial.print("  [-] Paquete [");
          Serial.print(i + 1);
          Serial.println("/10] en el aire...");
          
          delay(50); // Micro-pausa de 50ms para que la antena empiece a irradiar sin saturar su buffer
        }
        Serial.println(">>> RÁFAGA COMPLETADA. COHETE DEBE HABER RESPONDIDO. <<<\n");
      } 
      // COMANDO NORMAL (Un solo envío)
      else {
        Serial2.println(comandoUplink);
        Serial.println("\n--------------------------------------------------");
        Serial.print(">>> UPLINK ESTÁNDAR ENVIADO: ");
        Serial.println(comandoUplink);
        Serial.println("--------------------------------------------------\n");
      }
    }
  }
}