// #include <Arduino.h>

// // ==========================================
// // PINES DEL MÓDULO LORA (ESP32 WROOM)
// // ==========================================
// const int RX2_PIN = 16;
// const int TX2_PIN = 17;

// const int PIN_LORA_M0 = 15;
// const int PIN_LORA_M1 = 4;

// void setup() {
//   // 1. Configurar pines M0 y M1
//   pinMode(PIN_LORA_M0, OUTPUT);
//   pinMode(PIN_LORA_M1, OUTPUT);
  
//   // 2. Forzar MODO 0 (Modo Normal / Transmisión Transparente)
//   digitalWrite(PIN_LORA_M0, LOW);
//   digitalWrite(PIN_LORA_M1, LOW);

//   // 3. Iniciar puertos seriales
//   Serial.begin(115200); 
  
//   // Iniciar Serial2 asignando explícitamente los pines 16 y 17 a 115200 baudios
//   Serial2.begin(115200, SERIAL_8N1, RX2_PIN, TX2_PIN);

//   delay(2000);
  
//   Serial.println("==================================================");
//   Serial.println(" TEST LORA: ESP32 ESTACIÓN TERRENA INICIADA       ");
//   Serial.println(" Escribe aquí y se enviará al cohete (Teensy)     ");
//   Serial.println("==================================================");
// }

// void loop() {
//   // Si la computadora envía algo, pasarlo al LoRa
//   if (Serial.available()) {
//     String datosPC = Serial.readStringUntil('\n');
//     Serial.print("[Estación Terrena envía]: ");
//     Serial.println(datosPC);
//     Serial2.println(datosPC);
//   }

//   // Si el LoRa recibe algo por el aire, imprimirlo en la computadora
//   if (Serial2.available()) {
//     String datosLoRa = Serial2.readStringUntil('\n');
//     Serial.print("[Estación Terrena recibe]: ");
//     Serial.println(datosLoRa);
//   }
// }