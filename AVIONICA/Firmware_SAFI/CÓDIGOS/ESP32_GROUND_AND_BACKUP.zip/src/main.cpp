// #include <Arduino.h>
// #include <BluetoothSerial.h>

// // Objeto para manejar el Bluetooth Clásico
// BluetoothSerial SerialBT;

// // Definición de pines para el ESP32 (Hardware Serial 2)
// #define RXD2 16
// #define TXD2 17

// void setup() {
//   // Inicializar monitor serial para diagnóstico por cable
//   Serial.begin(115200);
  
//   // Inicializar comunicación con la Teensy a 115200 baudios
//   Serial2.begin(115200, SERIAL_8N1, RXD2, TXD2);

//   // Inicializar el Bluetooth con el nombre que verás en tu teléfono
//   SerialBT.begin("AKBALII_Telemetry"); 
  
//   Serial.println("ESP32 Inicializado.");
//   Serial.println("Bluetooth 'AKBALII_Telemetry' listo para emparejar.");
// }

// void loop() {
//   // TAREA ÚNICA: Modo "Puente" (Relay)
//   // Todo lo que el ESP32 escuche de la Teensy (Serial2), 
//   // lo retransmite inmediatamente por Bluetooth y al monitor de PC.
  
//   if (Serial2.available()) {
//     String tramaTelemetria = Serial2.readStringUntil('\n');
    
//     // Enviar al teléfono por Bluetooth (añadiendo el salto de línea)
//     SerialBT.println(tramaTelemetria);
    
//     // Imprimir en la PC para depuración
//     Serial.println(tramaTelemetria);
//   }

//   // Opcional: Si escribes algo en el teléfono, enviarlo a la Teensy
//   if (SerialBT.available()) {
//     Serial2.write(SerialBT.read());
//   }
// }