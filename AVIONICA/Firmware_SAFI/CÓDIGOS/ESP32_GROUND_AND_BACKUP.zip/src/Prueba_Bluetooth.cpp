// #include <Arduino.h>
// #include "BluetoothSerial.h"

// // ==========================================
// // CONFIGURACIÓN DE PINES (LORA E22)
// // ==========================================
// const int PIN_M0 = 15;
// const int PIN_M1 = 4;
// const int LORA_RX = 16; // Conectado al TX del LoRa
// const int LORA_TX = 17; // Conectado al RX del LoRa

// // ==========================================
// // OBJETO BLUETOOTH
// // ==========================================
// // Verifica que tu placa tenga Bluetooth Clásico habilitado en la compilación
// #if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
// #error El Bluetooth no está habilitado. Por favor, revisa tu configuración de placa.
// #endif

// BluetoothSerial SerialBT;

// void setup() {
//   // 1. Inicializar Consola PC
//   Serial.begin(115200); 
//   delay(2000);

//   Serial.println("==================================================");
//   Serial.println("  Estación Terrena AKBALL II: RF a Bluetooth       ");
//   Serial.println("==================================================");

//   // 2. Inicializar Bluetooth
//   // Este es el nombre que aparecerá cuando busques dispositivos en tu teléfono
//   SerialBT.begin("AKBAL II_Estacion"); 
//   Serial.println("Bluetooth iniciado. Dispositivo visible como 'AKBAL II_Estacion'.");

//   // 3. Configurar pines de control LoRa
//   pinMode(PIN_M0, OUTPUT);
//   pinMode(PIN_M1, OUTPUT);

//   // Forzar Modo 0 (Recepción Transparente)
//   digitalWrite(PIN_M0, LOW);
//   digitalWrite(PIN_M1, LOW);

//   // 4. Inicializar Hardware UART para LoRa (Serial2) a 9600 baudios
//   Serial2.begin(9600, SERIAL_8N1, LORA_RX, LORA_TX);
//   delay(100);
  
//   Serial.println("Módulo LoRa en escucha. Esperando telemetría...");
// }

// void loop() {
//   // =================================================================
//   // DIRECCIÓN 1: LORA -> BLUETOOTH (Telemetría entrante)
//   // =================================================================
//   if (Serial2.available()) {
//     // Leer todo el paquete hasta el salto de línea
//     String paquete = Serial2.readStringUntil('\n');
//     paquete.trim(); // Limpiar basura o retornos de carro

//     if (paquete.length() > 0) {
//       // 1. Mostrar en la computadora (Si está conectada por USB)
//       Serial.print(">> RF IN: ");
//       Serial.println(paquete);

//       // 2. Disparar el paquete hacia el teléfono Android por Bluetooth
//       SerialBT.println(paquete);
//     }
//   }

//   // =================================================================
//   // DIRECCIÓN 2: BLUETOOTH -> LORA (Comandos desde el teléfono)
//   // =================================================================
//   // Opcional: Si en el futuro quieres enviarle un comando al cohete
//   // (ej. "ABRIR_PARACAIDAS") desde la app del teléfono.
//   if (SerialBT.available()) {
//     String comandoApp = SerialBT.readStringUntil('\n');
//     comandoApp.trim();
    
//     if (comandoApp.length() > 0) {
//       Serial.print("<< BT CMD: ");
//       Serial.println(comandoApp);
      
//       // Enviar el comando por radiofrecuencia a la Teensy
//       Serial2.println(comandoApp);
//     }
//   }
// }