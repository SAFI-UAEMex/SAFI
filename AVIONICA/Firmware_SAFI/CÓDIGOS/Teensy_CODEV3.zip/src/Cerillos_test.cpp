#include <Arduino.h>

// ==========================================
// PINES DE CONFIGURACIÓN (TEENSY 4.1)
// ==========================================
const int PIN_DROGUE = 31; 
const int PIN_MAIN = 32;  

// ==========================================
// CONFIGURACIÓN DEL SECUENCIADOR (TIEMPOS)
// ==========================================
// El sufijo UL (Unsigned Long) previene el desbordamiento de memoria
const unsigned long TIEMPO_DROGUE = 10000UL; // 10,000 ms = 10 segundos
const unsigned long TIEMPO_MAIN = 25000UL;   // 25,000 ms = 25 segundos
const unsigned long DURACION_PULSO = 500UL; // 0.5 segundos de ignición

// ==========================================
// BANDERAS DE ESTADO 
// ==========================================
bool drogueDisparado = false; // Indica si ya pasaron 10s
bool mainDisparado = false;   // Indica si ya pasaron 25s

// Banderas de memoria para reemplazar el digitalRead()
bool drogueEnergizado = false; 
bool mainEnergizado = false;   

unsigned long tiempoInicioDrogue = 0;
unsigned long tiempoInicioMain = 0;
unsigned long ultimoPrintReloj = 0;

void setup() {
  // 1. SEGURIDAD FÍSICA INMEDIATA: Pines en salida y forzados a LOW
  pinMode(PIN_DROGUE, OUTPUT);
  digitalWrite(PIN_DROGUE, LOW);
  
  pinMode(PIN_MAIN, OUTPUT);
  digitalWrite(PIN_MAIN, LOW);

  // 2. Iniciar consola para monitoreo
  Serial.begin(115200);
  
  // Pausa para darte tiempo de abrir el Monitor Serial al conectar el USB
  delay(3000); 

  Serial.println("==================================================");
  Serial.println(" !!! SECUENCIADOR DE VUELO BASADO EN TIEMPO !!!   ");
  Serial.println("==================================================");
  Serial.println("ESTADO: Pines asegurados en LOW.");
  Serial.println("CRONOGRAMA:");
  Serial.println(" -> Drogue en T+ 10s");
  Serial.println(" -> Main en T+ 20s");
  Serial.println("==================================================\n");
}

void loop() {
  unsigned long tiempoActual = millis();

  // =======================================================
  // 1. RELOJ DE MONITOREO (Imprime cada 1 segundo)
  // =======================================================
  if (tiempoActual - ultimoPrintReloj >= 1000) {
    Serial.print("Tiempo activo de la placa: ");
    Serial.print(tiempoActual / 1000);
    Serial.println(" segundos");
    ultimoPrintReloj = tiempoActual;
  }

  // =======================================================
  // 2. SECUENCIA DE DISPARO DEL DROGUE (10 SEGUNDOS)
  // =======================================================
  if (tiempoActual >= TIEMPO_DROGUE && !drogueDisparado) {
    digitalWrite(PIN_DROGUE, HIGH); // FUEGO
    tiempoInicioDrogue = tiempoActual;
    
    drogueDisparado = true;
    drogueEnergizado = true; // Actualizamos la memoria
    
    Serial.println("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    Serial.println(">>> [T+ 10s] DISPARANDO CARGA DROGUE (PIN 31)    <<<");
    Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
  }

  // =======================================================
  // 3. SECUENCIA DE DISPARO DEL MAIN (20 SEGUNDOS)
  // =======================================================
  if (tiempoActual >= TIEMPO_MAIN && !mainDisparado) {
    digitalWrite(PIN_MAIN, HIGH); // FUEGO
    tiempoInicioMain = tiempoActual;
    
    mainDisparado = true;
    mainEnergizado = true; // Actualizamos la memoria
    
    Serial.println("\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    Serial.println(">>> [T+ 20s] DISPARANDO CARGA MAIN (PIN 32)      <<<");
    Serial.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
  }

  // =======================================================
  // 4. RUTINA DE APAGADO SEGURO (MÉTODO POR SOFTWARE FLAG)
  // =======================================================
  if (drogueEnergizado) {
    if (tiempoActual - tiempoInicioDrogue >= DURACION_PULSO) {
      digitalWrite(PIN_DROGUE, LOW); // CORTAR ENERGÍA
      drogueEnergizado = false;
      Serial.println("[-] Energía del Drogue cortada (Mosfet a salvo).");
    }
  }

  if (mainEnergizado) {
    if (tiempoActual - tiempoInicioMain >= DURACION_PULSO) {
      digitalWrite(PIN_MAIN, LOW); // CORTAR ENERGÍA
      mainEnergizado = false;
      Serial.println("[-] Energía del Main cortada (Mosfet a salvo).");
    }
  }
}