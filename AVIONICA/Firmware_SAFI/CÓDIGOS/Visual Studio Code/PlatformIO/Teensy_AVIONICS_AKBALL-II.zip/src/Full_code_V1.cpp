#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include "MS5611_SPI.h"
#include <TinyGPSPlus.h>

// ==========================================
// PINES DE CONFIGURACIÓN
// ==========================================
const int CS_IMU = 10;
const int CS_BARO = 38;

const int PIN_DROGUE = 31; 
const int PIN_MAIN = 32;  

// Pines del E220-900T30D
const int PIN_LORA_M0 = 2; // OUT2
const int PIN_LORA_M1 = 3; // LRCLK2

// ==========================================
// OBJETOS GLOBALES
// ==========================================
MS5611_SPI barometro(CS_BARO, &SPI1);
TinyGPSPlus gps;
File archivoVuelo;

const float GRAVEDAD = 9.80665;

unsigned long contadorLecturas = 0;
unsigned long tiempoAnteriorHz = 0;

// Temporizadores para Telemetría Dual
unsigned long tiempoAnteriorTx = 0;     // Para el ESP32 (10 Hz)
unsigned long tiempoAnteriorTxLoRa = 0; // Para el LoRa (10 Hz)

// ==========================================
// VARIABLES DE TELEMETRÍA Y CONTROL
// ==========================================
double latitud = 0.0;
double longitud = 0.0;
double altitud_gps = 0.0;
String horaGPS = "00:00:00";
String leyendaEstado = "0"; // Inicializado en estado PAD (0)

enum EstadoVuelo {
  ESTADO_PAD,              
  ESTADO_ASCENSO,          
  ESTADO_DESCENSO,         
  ESTADO_DROGUE_DESPLEGADO,
  ESTADO_MAIN_DESPLEGADO   
};

EstadoVuelo etapaActual = ESTADO_PAD;

float altitudBase = 0.0;    
float apogeoMaximo = 0.0;   

// Variables para el cálculo de Velocidad Vertical
float velocidadVertical = 0.0;
float altitudAnterior = 0.0;
unsigned long tiempoAnteriorVel = 0;

// Variables para el filtro de persistencia (Apogeo)
int lecturasDescendentes = 0;
const int CONFIRMACIONES_REQUERIDAS = 20; // 20 paquetes seguidos confirmando caída

unsigned long tiempoDisparoDrogue = 0;
unsigned long tiempoDisparoMain = 0;
const unsigned long DURACION_PULSO_PIRO = 2500; 

void setup() {
  // Inicializar canales pirotécnicos inmediatamente en BAJO por seguridad física
  pinMode(PIN_DROGUE, OUTPUT);
  digitalWrite(PIN_DROGUE, LOW);
  pinMode(PIN_MAIN, OUTPUT);
  digitalWrite(PIN_MAIN, LOW);

  // Configurar pines del LoRa para MODO NORMAL (M0=0, M1=0)
  pinMode(PIN_LORA_M0, OUTPUT);
  pinMode(PIN_LORA_M1, OUTPUT);
  digitalWrite(PIN_LORA_M0, LOW);
  digitalWrite(PIN_LORA_M1, LOW);

  // Inicialización de Puertos Seriales
  Serial.begin(115200); 
  Serial2.begin(115200); // Puerto del RYS352A
  Serial5.begin(115200); // Puerto de Telemetría hacia el ESP32 WROOM 32E
  Serial1.begin(115200); // Puerto de Telemetría hacia el E220-900T30D
  
  delay(100);

  Serial.println("======================================================");
  Serial.println("  AKBAL_II: Aviónica Integrada + Telemetría Dual      ");
  Serial.println("======================================================");

  // Inicializar MicroSD integrada
  Serial.print("Inicializando tarjeta microSD... ");
  if (!SD.begin(BUILTIN_SDCARD)) {
    Serial.println("FALLÓ. Operación continua sin almacenamiento local.");
  } else {
    Serial.println("OK.");
    archivoVuelo = SD.open("VUELO_AKBALII.csv", FILE_WRITE);
    if (archivoVuelo) {
      archivoVuelo.println("MET_ms,Hora_GPS,Fase,Lat,Lng,AltGPS_m,Ax,Ay,Az,Gx,Gy,Gz,T_IMU,T_Baro,AltAbs_m,Vel_ms,AltRel_m");
      archivoVuelo.flush();
    }
  }

  // Silenciar líneas SPI
  pinMode(CS_IMU, OUTPUT);
  digitalWrite(CS_IMU, HIGH);
  pinMode(CS_BARO, OUTPUT);
  digitalWrite(CS_BARO, HIGH);

  // Inicializar MPU9250 (SPI0)
  SPI.begin();
  delay(50);
  SPI.beginTransaction(SPISettings(115200, MSBFIRST, SPI_MODE3));
  digitalWrite(CS_IMU, LOW);
  SPI.transfer(0x6B); 
  SPI.transfer(0x00); 
  digitalWrite(CS_IMU, HIGH);
  SPI.endTransaction();

  // Inicializar MS5611 (SPI1)
  SPI1.setMOSI(26);
  SPI1.setMISO(39);
  SPI1.setSCK(27);
  SPI1.begin();
  delay(50);
  if (!barometro.begin()) {
    Serial.println("ERROR CRÍTICO: Barómetro no detectado.");
    while (1) { delay(10); } 
  }
  barometro.setOversampling(static_cast<osr_t>(4)); 
  
  // Configurar GPS a 10Hz
  Serial2.println("$PAIR050,100*22");
  delay(100);

  // Calcular nivel cero del suelo
  Serial.println("Calculando altitud base del terreno...");
  float sumaAlturas = 0;
  int muestrasValidas = 0;
  while (muestrasValidas < 50) {
    if (barometro.read() == MS5611_READ_OK) {
      float p = barometro.getPressure();
      sumaAlturas += 44330.0 * (1.0 - pow(p / 1013.25, 0.1903));
      muestrasValidas++;
      delay(20);
    }
  }
  altitudBase = sumaAlturas / 50.0;
  apogeoMaximo = altitudBase; 
  
  Serial.print("Altitud Base Establecida: "); Serial.print(altitudBase, 2); Serial.println(" m.");
  
  tiempoAnteriorHz = millis();
  tiempoAnteriorTx = millis();
  tiempoAnteriorTxLoRa = millis(); 
  tiempoAnteriorVel = millis();
}

void loop() {
  unsigned long tiempoActual = millis();
  contadorLecturas++;

  // =================================================================
  // TAREA 1: PARSING ASÍNCRONO DEL GPS
  // =================================================================
  while (Serial2.available() > 0) {
    if (gps.encode(Serial2.read())) {
      if (gps.location.isValid() && gps.location.isUpdated()) {
        latitud = gps.location.lat();
        longitud = gps.location.lng();
        altitud_gps = gps.altitude.isValid() ? gps.altitude.meters() : 0.0;
      }
      if (gps.time.isValid() && gps.time.isUpdated()) {
        int horaLocal = gps.time.hour() - 6;
        if (horaLocal < 0) {
          horaLocal += 24;
        }
        char bufferHora[16];
        snprintf(bufferHora, sizeof(bufferHora), "%02d:%02d:%02d", horaLocal, gps.time.minute(), gps.time.second());
        horaGPS = String(bufferHora);
      }
    }
  }

  // =================================================================
  // TAREA 2: EXTRACCIÓN EN RÁFAGA DEL IMU (SPI0)
  // =================================================================
  SPI.beginTransaction(SPISettings(115200, MSBFIRST, SPI_MODE3));
  digitalWrite(CS_IMU, LOW);
  SPI.transfer(0xBB); 

  int16_t ax_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  int16_t ay_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  int16_t az_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  int16_t temp_imu_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  int16_t gx_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  int16_t gy_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
  int16_t gz_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);

  digitalWrite(CS_IMU, HIGH);
  SPI.endTransaction();

  float ax = (ax_raw / 16384.0) * GRAVEDAD;
  float ay = (ay_raw / 16384.0) * GRAVEDAD;
  float az = (az_raw / 16384.0) * GRAVEDAD;
  float gx = gx_raw / 131.0;
  float gy = gy_raw / 131.0;
  float gz = gz_raw / 131.0;
  float temp_imu = (temp_imu_raw / 333.87) + 21.0;

  // =================================================================
  // TAREA 3: EXTRACCIÓN ATMOSFÉRICA MS5611 (SPI1)
  // =================================================================
  float temp_baro = 0, presion = 0, altitudActual = 0;
  if (barometro.read() == MS5611_READ_OK) {
    temp_baro = barometro.getTemperature();
    presion = barometro.getPressure();
    altitudActual = 44330.0 * (1.0 - pow(presion / 1013.25, 0.1903)); 
  }
  float altitudRelativa = altitudActual - altitudBase;

  // =================================================================
  // TAREA 4: MÁQUINA DE ESTADOS Y LEYENDAS DE DESPLEGUE
  // =================================================================
  switch (etapaActual) {
    case ESTADO_PAD:
      leyendaEstado = "0"; // PAD
      if (altitudRelativa > 50.0) {
        etapaActual = ESTADO_ASCENSO;
        Serial.println("\n[ALERTA COHETE] ¡DESPEGUE DETECTADO! Fase de ascenso iniciada.\n");
      }
      break;

    case ESTADO_ASCENSO:
      leyendaEstado = "1"; // ASCENSO
      if (altitudActual > apogeoMaximo) {
        apogeoMaximo = altitudActual;
        lecturasDescendentes = 0; 
      }
      
      if (altitudActual <= (apogeoMaximo - 2.0)) {
        lecturasDescendentes++;
        if (lecturasDescendentes >= CONFIRMACIONES_REQUERIDAS) {
          etapaActual = ESTADO_DESCENSO;
          Serial.println("\n[ALERTA COHETE] APOGEO CONFIRMADO. Iniciando fase de caída libre.\n");
        }
      } else {
        if (lecturasDescendentes > 0) lecturasDescendentes--;
      }
      break;

    case ESTADO_DESCENSO:
      leyendaEstado = "2"; // DESCENSO
      digitalWrite(PIN_DROGUE, HIGH); 
      tiempoDisparoDrogue = millis();
      etapaActual = ESTADO_DROGUE_DESPLEGADO;
      
      Serial.println("\n=======================================================");
      Serial.println(">>> ¡CRÍTICO: DETONACIÓN DE CARGA DROGUE ACTIVADA! <<<");
      Serial.println("=======================================================\n");
      break;

    case ESTADO_DROGUE_DESPLEGADO:
      leyendaEstado = "3"; // DROGUE_DESPLEGADO
      if (altitudRelativa <= 500.0) {
        digitalWrite(PIN_MAIN, HIGH);  
        tiempoDisparoMain = millis();
        etapaActual = ESTADO_MAIN_DESPLEGADO;
        
        Serial.println("\n=======================================================");
        Serial.println(">>> ¡CRÍTICO: DETONACIÓN DE CARGA MAIN ACTIVADA!    <<<");
        Serial.println("=======================================================\n");
      }
      break;

    case ESTADO_MAIN_DESPLEGADO:
      leyendaEstado = "4"; // MAIN_DESPLEGADO
      break;
  }

  if (digitalRead(PIN_DROGUE) == HIGH && (millis() - tiempoDisparoDrogue >= DURACION_PULSO_PIRO)) {
    digitalWrite(PIN_DROGUE, LOW);
  }
  if (digitalRead(PIN_MAIN) == HIGH && (millis() - tiempoDisparoMain >= DURACION_PULSO_PIRO)) {
    digitalWrite(PIN_MAIN, LOW);
  }

  // =================================================================
  // TAREA 5: CÁLCULO DE VELOCIDAD VERTICAL Y EMISIÓN (10 Hz)
  // =================================================================
  if (tiempoActual - tiempoAnteriorTx >= 100) { 
    
    // Calcular delta de tiempo real en segundos para máxima precisión
    float deltaT = (tiempoActual - tiempoAnteriorVel) / 1000.0;
    if (deltaT > 0) {
      velocidadVertical = (altitudRelativa - altitudAnterior) / deltaT;
    }
    
    altitudAnterior = altitudRelativa;
    tiempoAnteriorVel = tiempoActual;
    tiempoAnteriorTx = tiempoActual;

    // 1. Cadena COMPLETA para el ESP32 WROOM (Bluetooth / Caja Negra)
    String paqueteESP = String(tiempoActual) + "," +
                        horaGPS + "," +
                        leyendaEstado + "," +
                        String(latitud, 6) + "," +
                        String(longitud, 6) + "," +
                        String(altitud_gps, 1) + "," +
                        String(ax, 1) + "," +
                        String(ay, 1) + "," +
                        String(az, 1) + "," +
                        String(gx, 1) + "," +
                        String(gy, 1) + "," +
                        String(gz, 1) + "," +
                        String(temp_imu, 1) + "," +
                        String(temp_baro, 1) + "," +
                        String(altitudActual, 1) + "," + 
                        String(velocidadVertical, 1) + "," + 
                        String(altitudRelativa, 1);         

    // 2. Cadena reducida para el E220-900T30D
    String paqueteLoRa = String(altitudRelativa, 1) + "," +
                         String(temp_baro, 1) + "," +
                         String(presion, 1) + "," +
                         String(velocidadVertical, 1) + "," +
                         String(latitud, 6) + "," +
                         String(longitud, 6) + "," +
                         String(ax, 1) + "," +
                         String(ay, 1) + "," +
                         String(az, 1) + "," +
                         leyendaEstado;

    Serial5.println(paqueteESP);  
    Serial1.println(paqueteLoRa); 

    // Guardado en SD sincronizado a 10Hz
    if (archivoVuelo) {
      archivoVuelo.println(paqueteESP);
    }
  }

  // =================================================================
  // TAREA 6: CONSOLA DE DIAGNÓSTICO LOCAL Y FLUSH DE DATOS
  // =================================================================
  if (tiempoActual - tiempoAnteriorHz >= 1000) {
    Serial.print("Fase: "); Serial.print(leyendaEstado);
    Serial.print(" | AltRel: "); Serial.print(altitudRelativa, 1);
    Serial.print("m | VelVert: "); Serial.print(velocidadVertical, 1);
    Serial.print("m/s | Loop: "); Serial.print(contadorLecturas); Serial.println(" Hz");
    
    if (archivoVuelo) {
      archivoVuelo.flush(); 
    }

    contadorLecturas = 0;
    tiempoAnteriorHz = tiempoActual;
  }
}
// Todos los derechos reservados © 2026 - Emilio Flores Garduño - Sociedad Aeroespacial de la Facultad de Ingeniería (SAFI).