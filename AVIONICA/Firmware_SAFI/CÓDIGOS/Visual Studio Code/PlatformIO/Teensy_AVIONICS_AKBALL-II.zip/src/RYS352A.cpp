// #include <Arduino.h>
// #include <TinyGPSPlus.h>
// #include <SD.h>
// #include <SPI.h>

// #define GPS_BAUDRATE 115200

// TinyGPSPlus gps;
// File archivoVuelo; // Objeto global para el archivo de telemetría

// // Temporizador para la escritura segura de la SD
// unsigned long tiempoAnteriorSD = 0;
// // Haremos un volcado físico (flush) a la memoria flash cada 1 segundo (1000ms)
// const long intervaloSD = 1000; 

// void setup() {
  
//   Serial.begin(115200);
//   Serial2.begin(GPS_BAUDRATE);
//   Serial5.begin(115200); // Comunicación hacia el ESP32

//   while (!Serial && millis() < 3000); 
  
//   Serial.println("AKBAL_II: Inicializando telemetría y sistema de archivos...");

//   // =================================================================
//   // INICIALIZACIÓN DE LA TARJETA MICROSD INTEGRADA
//   // =================================================================
//   // En la Teensy 4.1 se debe utilizar específicamente la macro BUILTIN_SDCARD
//   if (!SD.begin(BUILTIN_SDCARD)) {
//     Serial.println("Error crítico: No se detecta la tarjeta microSD.");
//     // Nota: No usamos un loop infinito aquí (while(1)) porque la computadora 
//     // de vuelo debe seguir enviando telemetría serial aunque falle la SD.
//   } else {
//     Serial.println("microSD inicializada correctamente.");
    
//     // FILE_WRITE abre el archivo o lo crea si no existe. 
//     // Por seguridad, usamos nombres cortos en formato 8.3
//     archivoVuelo = SD.open("datosgps.csv", FILE_WRITE);
    
//     if (archivoVuelo) {
//       // Escribir la cabecera de las columnas
//       archivoVuelo.println("Latitud,Longitud,Altitud_m");
//       archivoVuelo.flush(); // Forzar el guardado del encabezado
//       Serial.println("Archivo datosgps.csv abierto y listo.");
//     } else {
//       Serial.println("Error: No se pudo crear el archivo.");
//     }
//   }

//   // =================================================================
//   // CONFIGURACIÓN DEL GPS RYS352A A 10Hz
//   // =================================================================
//   Serial.println("Enviando comando PAIR para habilitar 10Hz...");
//   Serial2.println("$PAIR050,100*22");
// }

// void loop() {
//   // =================================================================
//   // TAREA 1: Lectura de datos GPS a 10Hz
//   // =================================================================
//   while (Serial2.available() > 0) {
//     if (gps.encode(Serial2.read())) {
      
//       if (gps.location.isValid() && gps.location.isUpdated()) {
        
//         // Guardar en variables temporales para limpieza de código
//         double lat = gps.location.lat();
//         double lng = gps.location.lng();
//         double alt = gps.altitude.isValid() ? gps.altitude.meters() : 0.0;
        
//         // 1. Imprimir hacia la computadora por cable (Monitor Serial)
//         Serial.print("Latitud: ");
//         Serial.print(lat, 6);
//         Serial.print(" | Longitud: ");
//         Serial.print(lng, 6);
//         Serial.print(" | Altitud: ");
//         Serial.print(alt, 2);
//         Serial.println(" m");
        
//         // 2. ENVIAR AL ESP32 VÍA SERIAL5 PARA BLUETOOTH
//         Serial5.print("Latitud: ");
//         Serial5.print(lat, 6);
//         Serial5.print(" | Longitud: ");
//         Serial5.print(lng, 6);
//         Serial5.print(" | Altitud: ");
//         Serial5.print(alt, 2);
//         Serial5.println(" m");

//         // 3. Guardar en la tarjeta microSD en formato CSV
//         if (archivoVuelo) {
//           archivoVuelo.print(lat, 6);
//           archivoVuelo.print(",");
//           archivoVuelo.print(lng, 6);
//           archivoVuelo.print(",");
//           archivoVuelo.println(alt, 2);
//         }
//       }
//     }
//   }

//   // =================================================================
//   // TAREA 2: Diagnóstico visual LED (No bloqueante)
//   // =================================================================
//   unsigned long tiempoActual = millis();
  
//   if (tiempoActual - tiempoAnteriorLed >= intervaloLed) {
//     tiempoAnteriorLed = tiempoActual;
//     estadoLed = !estadoLed; 
//     digitalWrite(LED_PIN, estadoLed);
//   }

//   // =================================================================
//   // TAREA 3: Sincronización segura de la SD (Flush)
//   // =================================================================
//   // En caso de que se pierda la alimentación abruptamente, todo lo que no  
//   // haya hecho "flush" se perderá. Lo hacemos cada segundo para proteger 
//   // los datos sin estresar el bus SPI/SDIO a 10Hz.
//   if (tiempoActual - tiempoAnteriorSD >= intervaloSD) {
//     tiempoAnteriorSD = tiempoActual;
    
//     if (archivoVuelo) {
//       archivoVuelo.flush(); 
//     }
//   }
// }