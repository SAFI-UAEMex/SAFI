// #include <Arduino.h>
// #include <SPI.h>
// #include "MS5611_SPI.h"

// // ==========================================
// // PINES DE CONFIGURACIÓN
// // ==========================================
// const int CS_IMU = 10;
// const int CS_BARO = 38;

// // Pines del sistema de eyección pirotécnica
// const int PIN_DROGUE = 31; // CTX3 (Carga de apogeo / Paracaídas Drogue)
// const int PIN_MAIN = 32;   // OUT1B (Carga de baja altitud / Paracaídas Main)

// MS5611_SPI barometro(CS_BARO, &SPI1);

// const float GRAVEDAD = 9.80665;

// unsigned long contadorLecturas = 0;
// unsigned long tiempoAnterior = 0;

// // ==========================================
// // VARIABLES DE CONTROL DE VUELO (MÁQUINA DE ESTADOS)
// // ==========================================
// enum EstadoVuelo {
//   ESTADO_PAD,              // En riel de lanzamiento, calculando nivel del suelo
//   ESTADO_ASCENSO,          // Cohete subiendo, buscando el punto más alto
//   ESTADO_DESCENSO,         // Post-apogeo, esperando los 200m de caída para el Drogue
//   ESTADO_DROGUE_DESPLEGADO,// Drogue activo, descendiendo hacia la cota del Main
//   ESTADO_MAIN_DESPLEGADO   // Main activo, descenso finalizado o aterrizado
// };

// EstadoVuelo etapaActual = ESTADO_PAD;

// float altitudBase = 0.0;    // Altitud inicial de referencia en el riel (m)
// float apogeoMaximo = 0.0;   // El punto más alto registrado en vuelo (m)

// // Temporizadores de seguridad para los pulsos de los MOSFETs
// unsigned long tiempoDisparoDrogue = 0;
// unsigned long tiempoDisparoMain = 0;
// const unsigned long DURACION_PULSO_PIRO = 2000; // 2 segundos energizando el cerillo

// void setup() {
//   // 1. INICIALIZAR Y ASEGURAR SISTEMA DE EYECCIÓN (CRÍTICO)
//   // Configurar inmediatamente los pines en BAJO para evitar activaciones no deseadas en el arranque
//   pinMode(PIN_DROGUE, OUTPUT);
//   digitalWrite(PIN_DROGUE, LOW);
  
//   pinMode(PIN_MAIN, OUTPUT);
//   digitalWrite(PIN_MAIN, LOW);

//   Serial.begin(115200); 
//   delay(5000);

//   Serial.println("======================================================");
//   Serial.println("  AKBAL_II: Aviónica Integrada + Sistema de Eyección  ");
//   Serial.println("======================================================");

//   // 2. SILENCIAR CHIPS SPI
//   pinMode(CS_IMU, OUTPUT);
//   digitalWrite(CS_IMU, HIGH);
  
//   pinMode(CS_BARO, OUTPUT);
//   digitalWrite(CS_BARO, HIGH);

//   // 3. INICIALIZAR IMU MPU9250 (SPI0)
//   SPI.begin();
//   delay(50);

//   SPI.beginTransaction(SPISettings(115200, MSBFIRST, SPI_MODE3));
//   digitalWrite(CS_IMU, LOW);
//   SPI.transfer(0x6B); 
//   SPI.transfer(0x00); 
//   digitalWrite(CS_IMU, HIGH);
//   SPI.endTransaction();
  
//   Serial.println("IMU 6-DOF Inicializado en SPI0.");

//   // 4. INICIALIZAR BARÓMETRO MS5611 (SPI1)
//   SPI1.setMOSI(26);
//   SPI1.setMISO(39);
//   SPI1.setSCK(27);
//   SPI1.begin();
//   delay(50);

//   if (!barometro.begin()) {
//     Serial.println("ERROR CRÍTICO: Barómetro MS5611 no detectado.");
//     while (1) { delay(10); } 
//   }
  
//   barometro.setOversampling(4); // OSR=4096 (Máxima precisión para cálculo de altitud)
//   Serial.println("Barómetro MS5611 Inicializado en SPI1.");
  
//   // 5. CALCULAR ALTITUD BASE EN EL PAD
//   Serial.println("Estabilizando sensor y calculando altitud base del terreno...");
//   float sumaAlturas = 0;
//   int muestrasIniciales = 50;
//   int muestrasValidas = 0;
  
//   while (muestrasValidas < muestrasIniciales) {
//     if (barometro.read() == MS5611_READ_OK) {
//       float p = barometro.getPressure();
//       sumaAlturas += 44330.0 * (1.0 - pow(p / 1013.25, 0.1903));
//       muestrasValidas++;
//       delay(20);
//     }
//   }
//   altitudBase = sumaAlturas / muestrasIniciales;
//   apogeoMaximo = altitudBase; // Inicializar apogeo con la altura del suelo
  
//   Serial.print("Altitud Base en Riel Establecida: ");
//   Serial.print(altitudBase, 2);
//   Serial.println(" m sobre el nivel del mar.");
  
//   Serial.println("Arrancando lazo de telemetría y monitoreo de eyección...");
//   tiempoAnterior = millis();
// }

// void loop() {
//   // =================================================================
//   // TAREA 1: EXTRAER RÁFAGA DEL IMU (14 Bytes continuos)
//   // =================================================================
//   SPI.beginTransaction(SPISettings(115200, MSBFIRST, SPI_MODE3));
//   digitalWrite(CS_IMU, LOW);

//   SPI.transfer(0xBB); 

//   int16_t ax_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
//   int16_t ay_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
//   int16_t az_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);

//   int16_t temp_imu_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);

//   int16_t gx_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
//   int16_t gy_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);
//   int16_t gz_raw = (SPI.transfer(0x00) << 8) | SPI.transfer(0x00);

//   digitalWrite(CS_IMU, HIGH);
//   SPI.endTransaction();

//   float ax = (ax_raw / 16384.0) * GRAVEDAD;
//   float ay = (ay_raw / 16384.0) * GRAVEDAD;
//   float az = (az_raw / 16384.0) * GRAVEDAD;
  
//   float gx = gx_raw / 131.0;
//   float gy = gy_raw / 131.0;
//   float gz = gz_raw / 131.0;

//   float temp_imu = (temp_imu_raw / 333.87) + 21.0;

//   // =================================================================
//   // TAREA 2: EXTRAER DATOS ATMOSFÉRICOS (MS5611)
//   // =================================================================
//   float temp_baro = 0, presion = 0, altitudActual = 0;

//   if (barometro.read() == MS5611_READ_OK) {
//     temp_baro = barometro.getTemperature();
//     presion = barometro.getPressure();
//     altitudActual = 44330.0 * (1.0 - pow(presion / 1013.25, 0.1903));
//   }

//   // Altitud relativa calculada a partir del riel de lanzamiento
//   float altitudRelativa = altitudActual - altitudBase;

//   // =================================================================
//   // TAREA 3: ALGORITMO SENSING DE RECUPERACIÓN (FSM)
//   // =================================================================
//   switch (etapaActual) {
    
//     case ESTADO_PAD:
//       // Si detectamos un ascenso de más de 50 metros respecto al riel, declaramos despegue confirmado
//       if (altitudRelativa > 50.0) {
//         etapaActual = ESTADO_ASCENSO;
//       }
//       break;

//     case ESTADO_ASCENSO:
//       // Monitorear y registrar continuamente el punto más alto alcanzado
//       if (altitudActual > apogeoMaximo) {
//         apogeoMaximo = altitudActual;
//       }
      
//       // Si la altitud empieza a disminuir con respecto al apogeo máximo guardado, entramos en fase de descenso
//       if (altitudActual < (apogeoMaximo - 5.0)) { 
//         etapaActual = ESTADO_DESCENSO;
//       }
//       break;

//     case ESTADO_DESCENSO:
//       // Mantener actualizado el apogeo por si hubo una lectura falsa de descenso
//       if (altitudActual > apogeoMaximo) {
//         apogeoMaximo = altitudActual;
//       }
      
//       // CONDICIÓN LÓGICA DROGUE: Caída libre confirmada de 200m por debajo del apogeo
//       if (altitudActual <= (apogeoMaximo - 200.0)) {
//         digitalWrite(PIN_DROGUE, HIGH); // Activar MOSFET del cerillo electrónico del Drogue
//         tiempoDisparoDrogue = millis();
//         etapaActual = ESTADO_DROGUE_DESPLEGADO;
//       }
//       break;

//     case ESTADO_DROGUE_DESPLEGADO:
//       // CONDICIÓN LÓGICA MAIN: En caída, tras el drogue, al cruzar los 750m desde el punto inicial
//       if (altitudRelativa <= 750.0) {
//         digitalWrite(PIN_MAIN, HIGH);  // Activar MOSFET del cerillo electrónico del Main
//         tiempoDisparoMain = millis();
//         etapaActual = ESTADO_MAIN_DESPLEGADO;
//       }
//       break;

//     case ESTADO_MAIN_DESPLEGADO:
//       // Fase de descenso final / Aterrizaje logrado. Las cargas ya fueron iniciadas.
//       break;
//   }

//   // =================================================================
//   // TAREA 4: APAGADO DE SEGURIDAD DE CANALES PIROTÉCNICOS (No bloqueante)
//   // =================================================================
//   // Cortar la corriente de las líneas pirotécnicas tras pasar el tiempo establecido.
//   // Esto protege la batería y evita sobrecalentamiento en los MOSFETs debido a cortos post-explosión.
//   if (digitalRead(PIN_DROGUE) == HIGH && (millis() - tiempoDisparoDrogue >= DURACION_PULSO_PIRO)) {
//     digitalWrite(PIN_DROGUE, LOW);
//   }
  
//   if (digitalRead(PIN_MAIN) == HIGH && (millis() - tiempoDisparoMain >= DURACION_PULSO_PIRO)) {
//     digitalWrite(PIN_MAIN, LOW);
//   }

//   // =================================================================
//   // TAREA 5: IMPRESIÓN Y FORMATEO DE TELEMETRÍA
//   // =================================================================
//   Serial.print("Acel X:"); Serial.print(ax, 2);
//   Serial.print(" Y:"); Serial.print(ay, 2);
//   Serial.print(" Z:"); Serial.print(az, 2);
  
//   Serial.print(" || Giro X:"); Serial.print(gx, 2);
//   Serial.print(" Y:"); Serial.print(gy, 2);
//   Serial.print(" Z:"); Serial.print(gz, 2);
  
//   Serial.print(" || Alt_R:"); Serial.print(altitudRelativa, 1);
//   Serial.print("m Apog_M:"); Serial.print(apogeoMaximo - altitudBase, 1);
  
//   // Imprimir el estado actual del sistema de recuperación para monitoreo terrenal
//   Serial.print("m || ESTADO:");
//   switch(etapaActual) {
//     case ESTADO_PAD:               Serial.print("PAD"); break;
//     case ESTADO_ASCENSO:           Serial.print("ASCENSO"); break;
//     case ESTADO_DESCENSO:          Serial.print("DESCENSO"); break;
//     case ESTADO_DROGUE_DESPLEGADO: Serial.print("DROGUE_ACT"); break;
//     case ESTADO_MAIN_DESPLEGADO:   Serial.print("MAIN_ACT"); break;
//   }
//   Serial.println();

//   contadorLecturas++;

//   // =================================================================
//   // TAREA 6: DIAGNÓSTICO DE FRECUENCIA DEL SISTEMA
//   // =================================================================
//   unsigned long tiempoActual = millis();
//   if (tiempoActual - tiempoAnterior >= 1000) {
//     Serial.println("--------------------------------------------------");
//     Serial.print(">> FRECUENCIA DEL LOOP PRINCIPAL: ");
//     Serial.print(contadorLecturas);
//     Serial.println(" Hz <<");
//     Serial.println("--------------------------------------------------");
    
//     contadorLecturas = 0;
//     tiempoAnterior = tiempoActual;
//   }
// }