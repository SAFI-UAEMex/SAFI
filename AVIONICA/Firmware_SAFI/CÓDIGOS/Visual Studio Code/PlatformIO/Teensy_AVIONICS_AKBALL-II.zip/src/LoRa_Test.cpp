// #include <Arduino.h>

// // ==========================================
// // PINES DEL MÓDULO LORA (TEENSY 4.1)
// // ==========================================
// // RX1 = Pin 0, TX1 = Pin 1 (Hardware Serial1)
// const int PIN_LORA_M0 = 2; // OUT2
// const int PIN_LORA_M1 = 3; // LRCLK2

// void setup() {
//   // 1. Configurar pines M0 y M1
//   pinMode(PIN_LORA_M0, OUTPUT);
//   pinMode(PIN_LORA_M1, OUTPUT);
  
//   // 2. Forzar MODO 0 (Modo Normal / Transmisión Transparente)
//   digitalWrite(PIN_LORA_M0, LOW);
//   digitalWrite(PIN_LORA_M1, LOW);

//   // 3. Iniciar puertos seriales
//   Serial.begin(115200);  // Serial de la computadora
//   Serial1.begin(115200);   // Serial del LoRa (Baudrate por defecto de fábrica)

//   delay(2000);
  
//   Serial.println("==================================================");
//   Serial.println(" TEST LORA: TEENSY 4.1 INICIADA (MODO NORMAL)     ");
//   Serial.println(" Escribe aquí y se enviará a la Estación Terrena  ");
//   Serial.println("==================================================");
// }

// void loop() {
//   // Si la computadora envía algo, pasarlo al LoRa
//   if (Serial.available()) {
//     String datosPC = Serial.readStringUntil('\n');
//     Serial.print("[Teensy envía]: ");
//     Serial.println(datosPC);
//     Serial1.println(datosPC);
//   }

//   // Si el LoRa recibe algo por el aire, imprimirlo en la computadora
//   if (Serial1.available()) {
//     String datosLoRa = Serial1.readStringUntil('\n');
//     Serial.print("[Teensy recibe]: ");
//     Serial.println(datosLoRa);
//   }
// }