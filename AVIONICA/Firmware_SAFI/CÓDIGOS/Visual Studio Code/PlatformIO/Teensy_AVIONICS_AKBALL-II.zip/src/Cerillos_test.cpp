// #include <Arduino.h>

// // Pines de los MOSFETs en la Teensy 4.1
// const int PIN_DROGUE = 31; // CTX3
// const int PIN_MAIN = 32;   // OUT1B

// void setup() {
//   // 1. Configurar y asegurar pines inmediatamente al encender
//   pinMode(PIN_DROGUE, OUTPUT);
//   digitalWrite(PIN_DROGUE, LOW);
  
//   pinMode(PIN_MAIN, OUTPUT);
//   digitalWrite(PIN_MAIN, LOW);

//   Serial.begin(115200);
  
//   // Retardo de 5 segundos de seguridad antes de iniciar la secuencia
//   // Esto te da tiempo de alejarte si ya están conectados los cerillos
//   delay(5000);
  
//   Serial.println("==================================================");
//   Serial.println("    PRUEBA DE COMPUERTAS MOSFET (PIROTECNIA)      ");
//   Serial.println("==================================================");
//   Serial.println("Iniciando secuencia de prueba en loop...");
// }

// void loop() {
//   // =================================================================
//   // FASE 1: DISPARO DEL DROGUE (PIN 31)
//   // =================================================================
//   Serial.println("🔥 IGNICIÓN DROGUE (Pin 31) -> HIGH (Encendido)");
//   digitalWrite(PIN_DROGUE, HIGH);
//   delay(3000); // Mantener corriente por 2 segundos
  
//   // Apagar y enfriar
//   Serial.println("❄️ DROGUE OFF -> LOW (Pausa de 2 segundos)");
//   digitalWrite(PIN_DROGUE, LOW);
//   delay(5000); // 2 segundos de seguridad sin energía en ningún pin
  
//   // =================================================================
//   // FASE 2: DISPARO DEL MAIN (PIN 32)
//   // =================================================================
//   Serial.println("🔥 IGNICIÓN MAIN (Pin 32)   -> HIGH (Encendido)");
//   digitalWrite(PIN_MAIN, HIGH);
//   delay(3000); // Mantener corriente por 2 segundos
  
//   // Apagar y enfriar
//   Serial.println("❄️ MAIN OFF -> LOW (Pausa de 2 segundos)");
//   digitalWrite(PIN_MAIN, LOW);
//   delay(5000); // 2 segundos de seguridad antes de reiniciar el loop

//   Serial.println("--------------------------------------------------");
// }