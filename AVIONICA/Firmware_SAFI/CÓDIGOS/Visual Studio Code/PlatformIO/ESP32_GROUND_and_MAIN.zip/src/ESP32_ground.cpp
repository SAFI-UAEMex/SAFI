// #include <Arduino.h>

// // ==========================================
// // PINES DEL MÓDULO E22-900T22D
// // ==========================================
// // Serial2 del ESP32
// const int RX2_PIN = 16;
// const int TX2_PIN = 17;

// // Pines de Control de Modo
// const int PIN_LORA_M0 = 15;
// const int PIN_LORA_M1 = 4;

// void setup() {
//   // 1. Configurar pines de control como salidas
//   pinMode(PIN_LORA_M0, OUTPUT);
//   pinMode(PIN_LORA_M1, OUTPUT);
  
//   // 2. Forzar MODO 0 (Modo Normal / Transmisión Transparente)
//   digitalWrite(PIN_LORA_M0, LOW);
//   digitalWrite(PIN_LORA_M1, LOW);

//   // 3. Iniciar puerto serial de la computadora (Monitor Serial) a alta velocidad
//   Serial.begin(115200); 
  
//   // 4. Iniciar puerto serial para comunicarse con el LoRa
//   // IMPORTANTE: Está a 115200 baudios para soportar la ráfaga de 10 Hz.
//   // (Requiere que el módulo LoRa sea configurado previamente con el software RF_Setting)
//   Serial2.begin(115200, SERIAL_8N1, RX2_PIN, TX2_PIN);

//   delay(500);
  
//   Serial.println("\n==========================================================");
//   Serial.println(" [SISTEMA INICIADO] ESTACIÓN TERRENA AKBAL II             ");
//   Serial.println(" Microcontrolador: ESP32 WROOM 32                         ");
//   Serial.println(" RF: LoRa E22-900T22D (Modo Transparente)              ");
//   Serial.println("==========================================================");
  
//   // Imprimir el encabezado de las columnas para facilitar la lectura o exportación a Excel
//   Serial.println("Fase,Lat,Lng,AltGPS,Ax,Ay,Az,Gx,Gy,Gz,TempBaro,Presion,AltRelativa");
//   Serial.println("----------------------------------------------------------");
// }

// void loop() {
//   // Escuchar continuamente el puerto Serial2 (LoRa)
//   if (Serial2.available()) {
//     // Leer toda la cadena entrante hasta encontrar el salto de línea (\n)
//     String paqueteTelemetria = Serial2.readStringUntil('\n');
    
//     // Limpiar espacios en blanco o retornos de carro invisibles al inicio y final
//     paqueteTelemetria.trim();
    
//     // Si la cadena tiene datos válidos, imprimirla en la computadora
//     if (paqueteTelemetria.length() > 0) {
//       Serial.println(paqueteTelemetria);
//     }
//   }
// }