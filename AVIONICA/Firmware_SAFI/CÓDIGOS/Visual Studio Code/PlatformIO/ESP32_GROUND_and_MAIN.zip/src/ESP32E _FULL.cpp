#include <Arduino.h>
#include <BluetoothSerial.h>

// Bluetooth Clásico
BluetoothSerial SerialBT;

#define RXD2 16
#define TXD2 17

// ==========================================
// PINES DE EYECCIÓN DE RESPALDO
// ==========================================
const int PIN_DROGUE_BACKUP = 25; // IO25
const int PIN_MAIN_BACKUP = 26;   // IO26

// ==========================================
// PINES DE INTERFAZ Y SEÑALIZACIÓN
// ==========================================
const int PIN_LED_BT    = 4;  // Enciende al vincular Bluetooth
const int PIN_LED_DATOS = 33; // Enciende al recibir telemetría Teensy
const int PIN_BUZZER    = 32; // Alarma de 5 segundos al inicio de datos

// ==========================================
// CONTROL DE SEÑALES (TEMPORIZADORES NO BLOQUEANTES)
// ==========================================
unsigned long ultimoTiempoDatos = 0; 
bool primerPaqueteRecibido = false;  
unsigned long tiempoInicioBuzzer = 0;
bool buzzerEncendido = false; // Bandera lógica para el estado del buzzer

// ==========================================
// CONTROL DE RÁFAGAS VISUALES
// ==========================================
bool drogueDetectado = false;
unsigned long tiempoDrogueVis = 0;

bool mainDetectado = false;
unsigned long tiempoMainVis = 0;

const unsigned long DURACION_RAFAGA = 2000; 

// ==========================================
// MÁQUINA DE ESTADOS Y FILTROS DE APOGEO
// ==========================================
enum EstadoRespaldo {
  RESPALDO_PAD,
  RESPALDO_ASCENSO,
  RESPALDO_DESCENSO,
  RESPALDO_DROGUE_DESPLEGADO,
  RESPALDO_MAIN_DESPLEGADO
};

EstadoRespaldo estadoBackup = RESPALDO_PAD;
float apogeoMaximoESP = 0.0;

// Variables para el filtro de persistencia (Apogeo)
int lecturasDescendentes = 0;
const int CONFIRMACIONES_REQUERIDAS = 20; // 20 paquetes seguidos confirmando la caída

unsigned long tiempoDisparoDrogue = 0;
unsigned long tiempoDisparoMain = 0;
const unsigned long DURACION_PULSO_PIRO = 1500; 

void setup() {
  pinMode(PIN_DROGUE_BACKUP, OUTPUT);
  digitalWrite(PIN_DROGUE_BACKUP, LOW);
  
  pinMode(PIN_MAIN_BACKUP, OUTPUT);
  digitalWrite(PIN_MAIN_BACKUP, LOW);

  pinMode(PIN_LED_BT, OUTPUT);
  digitalWrite(PIN_LED_BT, LOW);

  pinMode(PIN_LED_DATOS, OUTPUT);
  digitalWrite(PIN_LED_DATOS, LOW);

  pinMode(PIN_BUZZER, OUTPUT);
  digitalWrite(PIN_BUZZER, LOW);

  Serial.begin(115200);
  delay(100);

  // Enlace UART directo 
  Serial2.begin(115200, SERIAL_8N1, RXD2, TXD2);
  SerialBT.begin("AKBALII_Telemetry"); 
  
  Serial.println("==================================================");
  Serial.println(" ESP32: Puente de Telemetría + BACK-UP Cerillos   ");
  Serial.println("==================================================");
}

void loop() {
  // =================================================================
  // TAREA 1: MONITOREO DE BLUETOOTH
  // =================================================================
  if (SerialBT.hasClient()) {
    digitalWrite(PIN_LED_BT, HIGH);
  } else {
    digitalWrite(PIN_LED_BT, LOW);
  }

  // =================================================================
  // TAREA 2: APAGADO DE SEGURIDAD (MOSFETS Y BUZZER)
  // =================================================================
  if (digitalRead(PIN_DROGUE_BACKUP) == HIGH && (millis() - tiempoDisparoDrogue >= DURACION_PULSO_PIRO)) {
    digitalWrite(PIN_DROGUE_BACKUP, LOW);
  }
  
  if (digitalRead(PIN_MAIN_BACKUP) == HIGH && (millis() - tiempoDisparoMain >= DURACION_PULSO_PIRO)) {
    digitalWrite(PIN_MAIN_BACKUP, LOW);
  }

 if (buzzerEncendido && (millis() - tiempoInicioBuzzer >= 5000)) {
    digitalWrite(PIN_BUZZER, LOW);
    buzzerEncendido = false; // <--- Reiniciamos la bandera
    Serial.println("\n[SISTEMA] Enlace Teensy estabilizado. Buzzer apagado.\n");
  }

  // Watchdog LED Datos
  if (digitalRead(PIN_LED_DATOS) == HIGH && (millis() - ultimoTiempoDatos >= 500)) {
    digitalWrite(PIN_LED_DATOS, LOW);
  }

  // =================================================================
  // TAREA 3: ESCUCHA Y PARSING DE TELEMETRÍA
  // =================================================================
  if (Serial2.available()) {
    String tramaTelemetria = Serial2.readStringUntil('\n');
    tramaTelemetria.trim(); 

    if (tramaTelemetria.length() > 0) {
      
      ultimoTiempoDatos = millis(); 
      digitalWrite(PIN_LED_DATOS, HIGH); 

      if (!primerPaqueteRecibido) {
        primerPaqueteRecibido = true;
        tiempoInicioBuzzer = millis();
        digitalWrite(PIN_BUZZER, HIGH);
        buzzerEncendido = true; // El software sabe que está encendido
        Serial.println("\n[SISTEMA] ¡DATOS ENTRANTES DETECTADOS! Activando alarma de 5 segundos...\n");
      }

      // EXTRACCIÓN DE ALTITUD
      int posicionUltimaComa = tramaTelemetria.lastIndexOf(',');
      
      if (posicionUltimaComa != -1) {
        String strAltitud = tramaTelemetria.substring(posicionUltimaComa + 1);
        float altitudRelativaESP = strAltitud.toFloat();

        // *****************************************************************
        // MÁQUINA DE ESTADOS (FSM) CON FILTRO DE TENDENCIA DE CAÍDA
        // *****************************************************************
        switch (estadoBackup) {
          case RESPALDO_PAD:
            if (altitudRelativaESP > 50.0) {
              estadoBackup = RESPALDO_ASCENSO;
            }
            break;

          case RESPALDO_ASCENSO:
            // 1. Actualizar siempre el punto más alto y limpiar el filtro si subimos
            if (altitudRelativaESP > apogeoMaximoESP) {
              apogeoMaximoESP = altitudRelativaESP;
              lecturasDescendentes = 0; 
            }
            
            // 2. Condición de detección de caída (2 metros por debajo del máximo)
            if (altitudRelativaESP <= (apogeoMaximoESP - 2.0)) {
              lecturasDescendentes++; // El sensor reporta que estamos cayendo
              
              // 3. Confirmación: Si han sido 20 lecturas seguidas, disparamos
              if (lecturasDescendentes >= CONFIRMACIONES_REQUERIDAS) {
                estadoBackup = RESPALDO_DESCENSO; 
              }
            } else {
              // Si fue una lectura ruidosa (cayó pero luego volvió a subir sin romper el apogeo)
              // descontamos el contador para exigir consistencia real en la caída.
              if (lecturasDescendentes > 0) lecturasDescendentes--;
            }
            break;

          case RESPALDO_DESCENSO:
            // Transición y ejecución del disparo en el instante que se confirmó el apogeo
            digitalWrite(PIN_DROGUE_BACKUP, HIGH);
            tiempoDisparoDrogue = millis();
            estadoBackup = RESPALDO_DROGUE_DESPLEGADO;
            Serial.println("\n[SISTEMA BACK-UP] DROGUE ACTIVADO A 2M DEL APOGEO!\n");
            break;

          case RESPALDO_DROGUE_DESPLEGADO:
            // Condición del Main a 500 metros respecto al suelo
            if (altitudRelativaESP <= 500.0) {
              digitalWrite(PIN_MAIN_BACKUP, HIGH);
              tiempoDisparoMain = millis();
              estadoBackup = RESPALDO_MAIN_DESPLEGADO;
              Serial.println("\n[SISTEMA BACK-UP] MAIN ACTIVADO A 500M!\n");
            }
            break;

          case RESPALDO_MAIN_DESPLEGADO:
            break;
        }
      }

      // -----------------------------------------------------------------
      // RÁFAGAS DE ALERTA VISUAL 
      // -----------------------------------------------------------------
      if (tramaTelemetria.indexOf("DROGUE_DESPLEGADO") != -1) {
        if (!drogueDetectado) {
          drogueDetectado = true;
          tiempoDrogueVis = millis();
        }
        if (millis() - tiempoDrogueVis <= DURACION_RAFAGA) {
          String alertaDrogue = "\n\r=====================================================\r\n"
                                ">>> VUELO: PARACAÍDAS DROGUE DESPLEGADO CONFIRMADO <<<\r\n"
                                "=====================================================\n\r";
          Serial.print(alertaDrogue);
          SerialBT.print(alertaDrogue);
        }
      }

      if (tramaTelemetria.indexOf("MAIN_DESPLEGADO") != -1) {
        if (!mainDetectado) {
          mainDetectado = true;
          tiempoMainVis = millis();
        }
        if (millis() - tiempoMainVis <= DURACION_RAFAGA) {
          String alertaMain = "\n\r=====================================================\r\n"
                              ">>> VUELO: PARACAÍDAS MAIN DESPLEGADO CONFIRMADO   <<<\r\n"
                              "=====================================================\n\r";
          Serial.print(alertaMain);
          SerialBT.print(alertaMain);
        }
      }

      // -----------------------------------------------------------------
      // RETRANSMISIÓN BLUETOOTH
      // -----------------------------------------------------------------
      SerialBT.println(tramaTelemetria);
      Serial.println(tramaTelemetria);
    }
  }
}